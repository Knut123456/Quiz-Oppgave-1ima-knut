# Quiz-Oppgave-1ima-knut
 
